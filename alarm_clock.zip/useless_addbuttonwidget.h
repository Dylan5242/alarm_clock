/*
#ifndef USELESS_ADDBUTTONWIDGET_H
#define USELESS_ADDBUTTONWIDGET_H

#include <QWidget>
#include <QPushButton>

class AddButtonWidget : public QWidget {
    Q_OBJECT
public:
    explicit AddButtonWidget(QWidget *parent = nullptr);

signals:
    void addRequested();

private slots:
    void onButtonClicked();

private:
    QPushButton *button;
};

#endif // USELESS_ADDBUTTONWIDGET_H
*/
